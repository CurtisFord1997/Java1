public class SammysMotto2
{
    public static void main(String[]args)
    {
        System.out.println("SsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSs");
        System.out.println("Ss                                    Ss");
        System.out.println("Ss                                    Ss");
        System.out.println("Ss                                    Ss");
        System.out.println("Ss                                    Ss");
        System.out.println("Ss  Sammy's makes it fun in the sun.  Ss");
        System.out.println("Ss                                    Ss");
        System.out.println("Ss                                    Ss");
        System.out.println("Ss                                    Ss");
        System.out.println("Ss                                    Ss");
        System.out.println("SsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSs");
    }
}
